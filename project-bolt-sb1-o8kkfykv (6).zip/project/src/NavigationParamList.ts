export type MainStackParamList = {
  Login: undefined;
  Route: undefined;
  Map: {
    segmentId: string;
  };
};